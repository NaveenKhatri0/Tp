# Don't use quotes( " and ' )
#SCRIPT BY SharpX72
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("8172562388:AAHn2lVZPlvob24Za4MaNL9m_3TBxLJC21c")

  #Enter Your telegram username here without @
OWNER_USERNAME=("SharpX72")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("1009132250")





  
